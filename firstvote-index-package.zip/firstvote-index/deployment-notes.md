# Fast deployment notes

## If you want a separate repo
1. Create a new GitHub repo named `firstvote-index`.
2. Upload all files from this folder to that repo.
3. If using GitHub Pages, keep frontend files in the repo root and enable Pages.
4. If using the backend too, deploy `server.js` on Render / Railway / Fly and point the frontend API there.

## Minimum launch path
- Launch static site first.
- Publish first audit.
- Add 3-5 more jurisdictions.
- Share in outreach emails and on Instagram / newsroom channels.
