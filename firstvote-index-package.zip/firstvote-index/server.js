const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DB = path.join(ROOT, 'audits.json');
if (!fs.existsSync(DB)) fs.writeFileSync(DB, '[]');
const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.json': 'application/json' };
function readDb() { return JSON.parse(fs.readFileSync(DB, 'utf8')); }
function writeDb(data) { fs.writeFileSync(DB, JSON.stringify(data, null, 2)); }
function send(res, code, data, type='application/json') { res.writeHead(code, { 'Content-Type': type }); res.end(type === 'application/json' ? JSON.stringify(data) : data); }
http.createServer((req, res) => {
  if (req.url === '/api/audits' && req.method === 'GET') return send(res, 200, readDb());
  if (req.url === '/api/audits' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      const row = JSON.parse(body || '{}');
      const data = readDb();
      data.unshift(row);
      writeDb(data);
      send(res, 201, row);
    });
    return;
  }
  const reqPath = req.url === '/' ? '/index.html' : req.url;
  const file = path.join(ROOT, reqPath.split('?')[0]);
  if (!file.startsWith(ROOT) || !fs.existsSync(file)) return send(res, 404, 'Not found', 'text/plain');
  send(res, 200, fs.readFileSync(file), types[path.extname(file)] || 'text/plain');
}).listen(PORT, () => console.log(`FirstVote Index running on http://localhost:${PORT}`));
