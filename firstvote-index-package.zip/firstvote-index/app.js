const STORAGE_KEY = 'firstvote_audits_v1';
const form = document.getElementById('auditForm');
const reportGrid = document.getElementById('reportGrid');

function getAudits() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}
function setAudits(audits) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(audits));
  render();
}
function overall(a) {
  return ((a.registration + a.absentee + a.education + a.usability) / 4).toFixed(1);
}
function grade(score) {
  const s = Number(score);
  if (s >= 4.5) return 'A';
  if (s >= 3.8) return 'B';
  if (s >= 3.0) return 'C';
  return 'D';
}
function render() {
  const audits = getAudits();
  reportGrid.innerHTML = audits.length ? '' : '<div class="card"><h3>No audits yet</h3><p class="muted">Submit the first one above or load demo data.</p></div>';
  audits.forEach((a, i) => {
    const score = overall(a);
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <p class="muted">${a.state}</p>
      <h3>${a.jurisdiction}</h3>
      <div class="report-score">${score}/5 · ${grade(score)}</div>
      <p><strong>Registration:</strong> ${a.registration}/5<br>
      <strong>Absentee / early vote:</strong> ${a.absentee}/5<br>
      <strong>Voter education:</strong> ${a.education}/5<br>
      <strong>Usability:</strong> ${a.usability}/5</p>
      ${a.notes ? `<p class="muted">${a.notes}</p>` : ''}
      <button class="button ghost" data-delete="${i}">Delete</button>
    `;
    reportGrid.appendChild(card);
  });
  document.querySelectorAll('[data-delete]').forEach(btn => {
    btn.onclick = () => {
      const audits = getAudits();
      audits.splice(Number(btn.dataset.delete), 1);
      setAudits(audits);
    };
  });
}
form.addEventListener('submit', e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const audit = {
    jurisdiction: data.jurisdiction.trim(),
    state: data.state.trim(),
    registration: Number(data.registration),
    absentee: Number(data.absentee),
    education: Number(data.education),
    usability: Number(data.usability),
    notes: data.notes.trim()
  };
  const audits = getAudits();
  audits.unshift(audit);
  setAudits(audits);
  form.reset();
  location.hash = '#reports';
});
document.getElementById('clearAll').onclick = () => setAudits([]);
document.getElementById('seedDemo').onclick = () => setAudits([
  {
    jurisdiction: 'Fulton County',
    state: 'Georgia',
    registration: 4,
    absentee: 4,
    education: 3,
    usability: 4,
    notes: 'Demo entry. Replace with real audit findings before publication.'
  }
]);
document.getElementById('downloadJson').onclick = () => download('firstvote-index-data.json', JSON.stringify(getAudits(), null, 2), 'application/json');
document.getElementById('downloadCsv').onclick = () => {
  const rows = getAudits();
  const header = ['jurisdiction','state','registration','absentee','education','usability','notes'];
  const csv = [header.join(',')].concat(rows.map(r => header.map(k => `"${String(r[k] ?? '').replaceAll('"','""')}"`).join(','))).join('\n');
  download('firstvote-index-data.csv', csv, 'text/csv');
};
function download(name, content, type) {
  const blob = new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}
render();
